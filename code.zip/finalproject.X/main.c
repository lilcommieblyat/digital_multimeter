
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/adcc.h"
#include "mcc_generated_files/i2c2.h"
#include "mcc_generated_files/eusart1.h"
#include <xc.h>
#include <stdio.h>




// Number of times to re-sample and average ADC for stable reading
#define OverSample  (32)

// Adjust the gain - this should be the input voltage that results in Vref at the ADC input pin
#define VMax10v (10.00)
#define VMax1v0 (0.99)
#define VMax0v1 (0.1)

// Adjust such that the ADC counts reads zero at zero volts (actually Vref/2 counts)
#define Offset0v1 134
#define Offset1v0 -7
#define Offset10v 0



// Accumulators to add multiple ADC samples into. 32-bit for extra range
uint32_t ADC10v_Total = 0;
uint32_t ADC1v0_Total = 0;    
uint32_t ADC0v1_Total = 0;    
uint32_t ADRef_Total = 0;
    
// These hold the last ADC reading for each channel. Used mostly for debugging to see raw ADC values.
int ADC_0v1_Raw;
int ADC_1v0_Raw;
int ADC_10v_Raw;
int ADC_Ref_Raw;
    
// Flags to mark if the ADC was in range. The value is cleared if any ADC sample was out of the range.
// USed to decide which votlage range to use for the output.
int ADCValid0v1;
int ADCValid1v0;
int ADCValid10v;

// Floating point value to calculate final voltage
float ADC_Voltage = -0.01;
int LastADCReading;
int LastHalfRef;

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    EUSART1_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    
    
    uint16_t count_down = 5000; // set countdown timer
    ENABLE_SetHigh();
    
    
    printf("Zhouming's Code Sstarted \n");

    while (1)
    {
         // Set all the valid flags back to true. 
        ADCValid0v1 = 0;
        ADCValid1v0 = 0;
        ADCValid10v = 0;
        
        // Initilize all accumulators to zero.
        ADRef_Total = 0;
        ADC10v_Total = 0; // Init accumulator
        ADC1v0_Total = 0;
        ADC0v1_Total = 0;
        
        // Repeat the ADC reading for the desired number of over-samples. 
        for (int i = 0; i < OverSample ;i++)
            {
                // Read the Vref input to scale the VDD referanced ADC value to the absolute reading 
                LastADCReading = ADCC_GetSingleConversion(ref_4096);
                ADC_Ref_Raw = LastADCReading;
                LastHalfRef = LastADCReading >> 1;
                ADRef_Total += ADC_Ref_Raw;
//                ADRef_Total += (LastADCReading - LastHalfRef);

                // Read the 10V input on RC3    
                LastADCReading = ADCC_GetSingleConversion(channel_10v);
                ADC_10v_Raw = LastADCReading; 
                ADC10v_Total += ADC_10v_Raw - Offset10v;
//                ADC10v_Total += (LastADCReading - LastHalfRef - Offset10v);

                // Read the 1V input on RC6    
                LastADCReading = ADCC_GetSingleConversion(channel_1v0);
                ADC_1v0_Raw = LastADCReading; 
                ADC1v0_Total += ADC_1v0_Raw - Offset1v0;
//                ADC1v0_Total += (LastADCReading - LastHalfRef - Offset1v0);

                // Read the 0.1V input on RC1                    
                LastADCReading = ADCC_GetSingleConversion(channel_0v1);
                ADC_0v1_Raw = LastADCReading; 
                ADC0v1_Total += ADC_0v1_Raw - Offset0v1;
//                ADC0v1_Total += (LastADCReading - LastHalfRef - Offset0v1);
            }
        ADRef_Total = ADRef_Total / OverSample;
        ADC10v_Total = ADC10v_Total / OverSample;
        if (ADC10v_Total < 4080 && ADC10v_Total > 0) ADCValid10v = 1;
        ADC1v0_Total = ADC1v0_Total / OverSample;
        if (ADC1v0_Total < 3450 && ADC1v0_Total > 10) ADCValid1v0 = 1;
        ADC0v1_Total = ADC0v1_Total / OverSample;
        if (ADC0v1_Total < 3400 && ADC0v1_Total > 100) ADCValid0v1 = 1;
        
        
        // Based on the lowest range of valid ADC readings, output the scaled text string
        if (ADCValid0v1) // the 0.1V range is valid
        {
            ADC_Voltage = (((1000 * VMax0v1) * ( ((float) ADC0v1_Total ) / ( (float) ADRef_Total ))) * 2) - (VMax0v1 * 1000);   
//            if (abs(ADC_Voltage) <= 0.1)
//            {
//                ADC_Voltage = 0;
//                printf("V0.1: %.1f mV\t", ADC_Voltage);
//            }
//            else
//            {
                printf("V0.1: %.1f mV\t", ADC_Voltage);
//            }
        }
        else if (ADCValid1v0)  // the 1.0V range is valid 
        {
            ADC_Voltage = ((VMax1v0 * ( ((float) ADC1v0_Total ) / ((float) ADRef_Total))) * 2) - VMax1v0;  
            printf("V1.0: %.3f V\t", ADC_Voltage);
        }
        else if (ADCValid10v)  // the 10V range is valid
        {  
            ADC_Voltage = ((VMax10v * (((float) ADC10v_Total ) / ((float) ADRef_Total))) * 2) - VMax10v;
            printf("V10: %.3f V\t", ADC_Voltage);
        }
        else // Nothing was valid
        {
            printf("V: Out Of Range!    ");
        }
        
        // These lines can be used with a terminal for debugging
//        printf("A0v1: %d\t", ADC0v1_Total);
//        printf("A1v0: %d\t", ADC1v0_Total);
//        printf("A10v: %d\t", ADC10v_Total);
//        printf("A0v1: %d\t", ADC_0v1_Raw);
//        printf("A1v0: %d\t", ADC_1v0_Raw);
//        printf("A10v: %d\t", ADC_10v_Raw);
//        printf("REF: %i\t", ADRef_Total);
        printf("CNT: %i\t", count_down);
        printf("\n");
    
        if (count_down <= 1)
            ENABLE_SetLow();  //ENABLE pin set low 
        else
            count_down--;
    }
    return;
}
/**
 End of File
*/